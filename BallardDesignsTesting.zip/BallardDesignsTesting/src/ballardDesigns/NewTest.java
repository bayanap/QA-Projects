package ballardDesigns;

import org.testng.Assert;
import org.testng.annotations.*;
import org.testng.annotations.BeforeMethod;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

public class NewTest {
	WebDriver driver;

	@BeforeSuite
	public void testSetup() {
		String driverPath = "C:\\Users\\bayan\\eclipse-workspace\\hi\\exefiles\\chromedriver.exe";

		System.setProperty("webdriver.chrome.driver", driverPath);

		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().window().maximize();

	}

	@BeforeTest
	public void openBrowser() throws InterruptedException {
		driver.get("https://www.ballarddesigns.com/");
		 Thread.sleep(2000);
		System.out.println("We are currently on the following URL" + driver.getCurrentUrl());

	}

	@AfterTest
	public void closeBrowser() throws InterruptedException {
		 Thread.sleep(8000);

		driver.quit();
	}

	@Test(priority = 2)
	public void verifyLogo() throws Exception {

		driver.findElement(By.className("logo-anchor")).click();

		System.out.println("Logo is Display");
		Thread.sleep(2000);
		driver.navigate().refresh();

	}

	@Test(priority = 1)
	public void verifyLogIn() throws InterruptedException {

		WebElement log_in = driver.findElement(By.xpath("//*[@id=\"loginMyAccount\"]/span"));
		log_in.click();
		 Thread.sleep(2000);

		// identify email,password,login

		WebElement email = driver.findElement(By.id("logonId"));
		WebElement password = driver.findElement(By.id("logonPassword"));
		WebElement loginButton = driver.findElement(By.id("logonButton"));
		 Thread.sleep(2000);

		String my_email = "bayanazar15@gmail.com";
		String my_password = "1qaz1QAZ@";
		email.clear();
		email.sendKeys(my_email);
		System.out.println("Email is enter");
		 Thread.sleep(2000);

		password.clear();
		password.sendKeys(my_password);
		System.out.println("Password is enter");
		 Thread.sleep(2000);

		loginButton.click();
		System.out.println("LOG IN is successful");

	}
@Test(priority=2)
public void verifyWelcome() throws InterruptedException {
	WebElement welcome_msg = driver.findElement(By.className("WelcomeAccountPane"));

String actual ="Welcome to your account at Ballard Designs.";
		
String expected=welcome_msg.getText();
Assert.assertEquals(actual, expected);
}

@Test(priority=3)
public void verifyMyAccount() throws InterruptedException {
	WebElement my_account = driver.findElement(By.xpath("//*[@id=\"myAccount\"]/a/span"));

String actual ="My Account";
		
String expected=my_account.getText();
Assert.assertEquals(actual, expected);
}
}


