package sel;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class LunchChromDemo {
	public static void main(String args[])
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\bayan\\eclipse-workspace\\SeleniumTest\\exefiles\\geckodriver.exe");		

		WebDriver driver = new ChromeDriver();
driver.na
		
		
	}
}
