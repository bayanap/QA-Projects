package frontgateTestNG;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;

import org.testng.annotations.DataProvider;

import org.testng.annotations.Test;

public class DataProviderTest {

    private static WebDriver driver;

  @DataProvider(name = "Authentication")

  public static Object[][] credentials() {

        // The number of times data is repeated, test will be executed the same no. of times

        // Here it will execute two times

        return new Object[][] { { "bayanazar15", "" }, { "bayanazar15@gmail.com", "qazzaq1" }, { "bayanazar15@gmail.com", "1qaz1QAZ@" }};

  }

  // Here we are calling the Data Provider object with its Name

  @Test(dataProvider = "Authentication")

  public void test(String sUsername, String sPassword) {

      driver = new FirefoxDriver();

      driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

      driver.get("https://www.frontgate.com/ShoppingCartView");

      driver.findElement(By.xpath("//*[@id=\"monetate_selectorHTML_48e627cb_0\"]/p/a")).click();

      // Argument passed will be used here as String Variable

      driver.findElement(By.id("logonId")).sendKeys(sUsername);

      driver.findElement(By.id("logonPassword")).sendKeys(sPassword);

      driver.findElement(By.id("logonButton")).click();
      System.out.println(" Login Successfully, now it is the time to Log Off buddy.");

      driver.findElement(By.xpath("//*[@id=\"accountMenu\"]")).click();
      driver.findElement(By.xpath("//*[@id=\"login\"]")).click();
      driver.quit();

  }

}